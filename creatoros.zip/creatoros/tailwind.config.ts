import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: { bg: "#101116", panel: "#181a22", line: "#2a2d3a", accent: "#9d8cff", muted: "#a0a5b8" } } },
  plugins: [],
} satisfies Config;
