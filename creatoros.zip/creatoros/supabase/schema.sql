-- Not yet wired to the app. Run in the Supabase SQL editor when you add the data layer.
create table ideas (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  title text not null, notes text not null default '', archived boolean not null default false,
  project_id uuid, created_at timestamptz not null default now()
);
create table projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  title text not null,
  stage text not null default 'Research' check (stage in ('Research','Script','Thumbnail','Scheduled','Published')),
  script text not null default '', publish_date date, created_at timestamptz not null default now()
);
create table tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  project_id uuid not null references projects on delete cascade,
  title text not null, due date, done boolean not null default false, created_at timestamptz not null default now()
);
alter table ideas enable row level security;
alter table projects enable row level security;
alter table tasks enable row level security;
create policy "own ideas" on ideas for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own projects" on projects for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own tasks" on tasks for all using (user_id = auth.uid()) with check (user_id = auth.uid());
