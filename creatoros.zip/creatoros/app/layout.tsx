import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "CreatorOS", description: "From idea to upload, one creative command center." };
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
