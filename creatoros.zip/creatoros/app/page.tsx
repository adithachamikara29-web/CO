import Link from "next/link";
export default function Landing() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <p className="font-semibold text-accent">CreatorOS</p>
      <h1 className="mt-4 text-4xl font-bold md:text-5xl">From idea to upload, one creative command center.</h1>
      <p className="mt-4 text-muted">Capture ideas, turn them into projects, track tasks and write scripts in one place. This build runs in demo mode: your data stays in this browser.</p>
      <Link href="/app" className="btn mt-8 inline-block">Open the demo workspace</Link>
    </main>
  );
}
