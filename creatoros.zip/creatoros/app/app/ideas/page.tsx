"use client";
import { useState, FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";

export default function Ideas() {
  const s = useStore();
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [err, setErr] = useState("");
  const list = s.ideas.filter((i) => !i.archived);
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return setErr("Give the idea a title.");
    s.addIdea(title.trim(), notes.trim());
    setTitle(""); setNotes(""); setErr("");
  };
  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="text-2xl font-bold">Ideas</h1>
      <form onSubmit={submit} className="card space-y-3" noValidate>
        <div>
          <label htmlFor="t" className="mb-1 block text-sm">Idea title</label>
          <input id="t" className="input" value={title} onChange={(e) => setTitle(e.target.value)} aria-describedby={err ? "e" : undefined} aria-invalid={!!err} />
          {err && <p id="e" role="alert" className="mt-1 text-sm">{err}</p>}
        </div>
        <div>
          <label htmlFor="n" className="mb-1 block text-sm">Notes (optional)</label>
          <textarea id="n" rows={3} className="input" value={notes} onChange={(e) => setNotes(e.target.value)} />
        </div>
        <button className="btn">Save idea</button>
      </form>
      {list.length === 0 ? <p className="text-sm text-muted">No ideas yet. Save the first one above.</p> : (
        <ul className="space-y-3">
          {list.map((i) => (
            <li key={i.id} className="card">
              <p className="font-semibold">{i.title}{i.sample && <span className="ml-2 text-xs text-muted">(sample)</span>}</p>
              {i.notes && <p className="mt-1 whitespace-pre-wrap text-sm text-muted">{i.notes}</p>}
              <div className="mt-3 flex gap-2">
                {i.projectId ? <Link className="btn-ghost" href={`/app/projects/${i.projectId}`}>Open project</Link> : (
                  <button className="btn" onClick={() => { const id = s.convertIdea(i.id); if (id) router.push(`/app/projects/${id}`); }}>Turn into project</button>
                )}
                <button className="btn-ghost" onClick={() => s.archiveIdea(i.id)}>Archive</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
