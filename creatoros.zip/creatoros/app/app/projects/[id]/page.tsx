"use client";
import { useEffect, useState, FormEvent } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { STAGES, Stage } from "@/lib/types";
import { useStore } from "@/lib/store";

export default function ProjectPage() {
  const { id } = useParams<{ id: string }>();
  const s = useStore();
  const p = s.projects.find((x) => x.id === id);
  const tasks = s.tasks.filter((t) => t.projectId === id);
  const [script, setScript] = useState("");
  const [saved, setSaved] = useState(true);
  const [title, setTitle] = useState("");
  const [due, setDue] = useState("");
  useEffect(() => { if (p) { setScript(p.script); setSaved(true); } }, [p?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!p) return <p>Project not found. <Link className="underline" href="/app/projects">Back to projects</Link></p>;
  const words = script.trim() ? script.trim().split(/\s+/).length : 0;
  const add = (e: FormEvent) => { e.preventDefault(); if (!title.trim()) return; s.addTask(p.id, title.trim(), due); setTitle(""); setDue(""); };

  return (
    <div className="max-w-3xl space-y-8">
      <div>
        <Link href="/app/projects" className="text-sm text-muted hover:text-white">Back to projects</Link>
        <h1 className="mt-1 text-2xl font-bold">{p.title}</h1>
        {p.sample && <p className="text-xs text-muted">Sample project</p>}
      </div>
      <div className="flex flex-wrap gap-4">
        <div>
          <label htmlFor="st" className="mb-1 block text-sm">Stage</label>
          <select id="st" className="input" value={p.stage} onChange={(e) => s.updateProject(p.id, { stage: e.target.value as Stage })}>
            {STAGES.map((x) => <option key={x}>{x}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="pd" className="mb-1 block text-sm">Publish date</label>
          <input id="pd" type="date" className="input" value={p.publishDate ?? ""} onChange={(e) => s.updateProject(p.id, { publishDate: e.target.value || undefined })} />
        </div>
      </div>
      <section aria-labelledby="tk">
        <h2 id="tk" className="mb-3 font-semibold">Tasks</h2>
        <form onSubmit={add} className="mb-3 flex flex-wrap gap-2">
          <label className="sr-only" htmlFor="tt">Task title</label>
          <input id="tt" className="input flex-1" placeholder="New task" value={title} onChange={(e) => setTitle(e.target.value)} />
          <label className="sr-only" htmlFor="td">Due date</label>
          <input id="td" type="date" className="input w-auto" value={due} onChange={(e) => setDue(e.target.value)} />
          <button className="btn">Add task</button>
        </form>
        {tasks.length === 0 ? <p className="text-sm text-muted">No tasks yet.</p> : (
          <ul className="space-y-2">
            {tasks.map((t) => (
              <li key={t.id} className="card flex items-center gap-3 text-sm">
                <input type="checkbox" id={t.id} checked={t.done} onChange={() => s.toggleTask(t.id)} className="h-4 w-4" />
                <label htmlFor={t.id} className={`flex-1 ${t.done ? "text-muted line-through" : ""}`}>{t.title}{t.due && <span className="ml-2 text-muted">Due {t.due}</span>}</label>
                <button className="btn-ghost" onClick={() => s.deleteTask(t.id)} aria-label={`Delete task ${t.title}`}>Delete</button>
              </li>
            ))}
          </ul>
        )}
      </section>
      <section aria-labelledby="sc">
        <h2 id="sc" className="mb-3 font-semibold">Script</h2>
        <label htmlFor="sx" className="sr-only">Script</label>
        <textarea id="sx" rows={14} className="input font-mono" value={script} onChange={(e) => { setScript(e.target.value); setSaved(false); }} placeholder="Write your script here. No AI generation is connected in this build." />
        <div className="mt-2 flex items-center gap-3">
          <button className="btn" disabled={saved} onClick={() => { s.updateProject(p.id, { script }); setSaved(true); }}>Save script</button>
          <span className="text-sm text-muted" aria-live="polite">{saved ? "All changes saved" : "Unsaved changes"} · {words} words</span>
        </div>
      </section>
    </div>
  );
}
