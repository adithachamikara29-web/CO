"use client";
import Link from "next/link";
import { useStore } from "@/lib/store";

export default function Projects() {
  const s = useStore();
  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="text-2xl font-bold">Projects</h1>
      {s.projects.length === 0 ? (
        <p className="text-sm text-muted">No projects yet. Turn an idea into a project from the <Link className="underline" href="/app/ideas">Ideas</Link> page.</p>
      ) : (
        <ul className="space-y-3">
          {s.projects.map((p) => {
            const t = s.tasks.filter((x) => x.projectId === p.id);
            return (
              <li key={p.id}>
                <Link href={`/app/projects/${p.id}`} className="card block hover:border-accent">
                  <p className="font-semibold">{p.title}</p>
                  <p className="mt-1 text-sm text-muted">Stage: {p.stage} · Tasks done: {t.filter((x) => x.done).length} of {t.length}</p>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
