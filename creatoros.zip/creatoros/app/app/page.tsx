"use client";
import Link from "next/link";
import { STAGES } from "@/lib/types";
import { useStore } from "@/lib/store";

export default function Mission() {
  const s = useStore();
  const open = s.tasks.filter((t) => !t.done).sort((a, b) => (a.due ?? "9").localeCompare(b.due ?? "9")).slice(0, 6);
  const isEmpty = !s.ideas.length && !s.projects.length;
  return (
    <div className="max-w-4xl space-y-8">
      <h1 className="text-2xl font-bold">Mission Control</h1>
      {isEmpty && (
        <div className="card">
          <p>Your workspace is empty. Capture your first idea, or load sample data to look around.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Link className="btn" href="/app/ideas">Capture an idea</Link>
            <button className="btn-ghost" onClick={s.loadSample}>Load labelled sample data</button>
          </div>
        </div>
      )}
      <section aria-labelledby="pipe">
        <h2 id="pipe" className="mb-3 font-semibold">Pipeline</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {STAGES.map((st) => (
            <div key={st} className="card">
              <p className="text-2xl font-bold">{s.projects.filter((p) => p.stage === st).length}</p>
              <p className="text-sm text-muted">{st}</p>
            </div>
          ))}
        </div>
      </section>
      <section aria-labelledby="next">
        <h2 id="next" className="mb-3 font-semibold">Open tasks</h2>
        {open.length === 0 ? <p className="text-sm text-muted">No open tasks. Add tasks from a project page.</p> : (
          <ul className="space-y-2">
            {open.map((t) => (
              <li key={t.id} className="card flex justify-between gap-3 text-sm">
                <Link href={`/app/projects/${t.projectId}`} className="hover:underline">{t.title}</Link>
                <span className="text-muted">{t.due ? `Due ${t.due}` : "No due date"}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
      {!isEmpty && (
        <button className="btn-ghost" onClick={() => confirm("Delete all ideas, projects and tasks from this browser?") && s.reset()}>Reset demo data</button>
      )}
    </div>
  );
}
