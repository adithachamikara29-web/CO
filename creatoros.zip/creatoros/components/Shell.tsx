"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ReactNode } from "react";
import { StoreProvider, useStore } from "@/lib/store";

const nav = [["/app", "Mission Control"], ["/app/ideas", "Ideas"], ["/app/projects", "Projects"]];

function Inner({ children }: { children: ReactNode }) {
  const path = usePathname();
  const s = useStore();
  return (
    <div className="min-h-screen md:flex">
      <aside className="border-b border-line p-3 md:w-56 md:border-b-0 md:border-r md:p-4">
        <Link href="/" className="font-semibold text-accent">CreatorOS</Link>
        <nav className="mt-3 flex gap-1 md:flex-col" aria-label="Main">
          {nav.map(([h, l]) => {
            const on = h === "/app" ? path === h : path.startsWith(h);
            return (
              <Link key={h} href={h} aria-current={on ? "page" : undefined}
                className={`rounded px-3 py-2 text-sm ${on ? "bg-panel font-semibold text-white" : "text-muted hover:text-white"}`}>{l}</Link>
            );
          })}
        </nav>
        <p className="mt-4 hidden text-xs text-muted md:block">Demo mode: data is saved only in this browser.</p>
      </aside>
      <main className="min-w-0 flex-1 p-4 md:p-8">
        {s.saveError && <p role="alert" className="mb-4 rounded border border-line p-3 text-sm">Could not save to this browser. Changes may be lost when you close the tab.</p>}
        {s.ready ? children : <p className="text-muted">Loading workspace</p>}
      </main>
    </div>
  );
}
export default function Shell({ children }: { children: ReactNode }) {
  return <StoreProvider><Inner>{children}</Inner></StoreProvider>;
}
