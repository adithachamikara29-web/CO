export const STAGES = ["Research", "Script", "Thumbnail", "Scheduled", "Published"] as const;
export type Stage = (typeof STAGES)[number];
export type Idea = { id: string; title: string; notes: string; archived: boolean; projectId?: string; sample?: boolean };
export type Project = { id: string; title: string; stage: Stage; script: string; publishDate?: string; sample?: boolean };
export type Task = { id: string; projectId: string; title: string; due?: string; done: boolean };
