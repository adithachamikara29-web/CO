"use client";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { Idea, Project, Task } from "./types";

const KEY = "creatoros-demo-v1";
type State = { ideas: Idea[]; projects: Project[]; tasks: Task[] };
const empty: State = { ideas: [], projects: [], tasks: [] };
const uid = () => crypto.randomUUID();

type Ctx = State & {
  ready: boolean; saveError: boolean;
  addIdea(title: string, notes: string): void;
  archiveIdea(id: string): void;
  convertIdea(id: string): string | null;
  updateProject(id: string, patch: Partial<Project>): void;
  addTask(projectId: string, title: string, due?: string): void;
  toggleTask(id: string): void;
  deleteTask(id: string): void;
  loadSample(): void;
  reset(): void;
};
const StoreCtx = createContext<Ctx | null>(null);
export const useStore = () => {
  const c = useContext(StoreCtx);
  if (!c) throw new Error("useStore must be used inside StoreProvider");
  return c;
};

export function StoreProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<State>(empty);
  const [ready, setReady] = useState(false);
  const [saveError, setSaveError] = useState(false);

  useEffect(() => {
    try { const raw = localStorage.getItem(KEY); if (raw) setS(JSON.parse(raw)); } catch { setSaveError(true); }
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready) return;
    try { localStorage.setItem(KEY, JSON.stringify(s)); setSaveError(false); } catch { setSaveError(true); }
  }, [s, ready]);

  const up = (fn: (p: State) => State) => setS(fn);
  const convertIdea = (id: string) => {
    const idea = s.ideas.find((i) => i.id === id);
    if (!idea) return null;
    if (idea.projectId) return idea.projectId;
    const pid = uid();
    up((p) => ({
      ...p,
      projects: [...p.projects, { id: pid, title: idea.title, stage: "Research", script: "", sample: idea.sample }],
      ideas: p.ideas.map((i) => (i.id === id ? { ...i, projectId: pid } : i)),
    }));
    return pid;
  };
  const loadSample = () => {
    const pid = uid();
    up((p) => ({
      ideas: [...p.ideas, { id: uid(), title: "Sample: 5 mistakes new editors make", notes: "Sample idea. Delete or archive it any time.", archived: false, sample: true }],
      projects: [...p.projects, { id: pid, title: "Sample: Editing basics video", stage: "Script", script: "Sample script.\n\nHook: the one mistake that costs you viewers.", sample: true }],
      tasks: [...p.tasks,
        { id: uid(), projectId: pid, title: "Record voiceover", due: new Date(Date.now() + 2 * 864e5).toISOString().slice(0, 10), done: false },
        { id: uid(), projectId: pid, title: "Outline the five mistakes", done: true }],
    }));
  };
  const value: Ctx = {
    ...s, ready, saveError, convertIdea, loadSample,
    addIdea: (title, notes) => up((p) => ({ ...p, ideas: [{ id: uid(), title, notes, archived: false }, ...p.ideas] })),
    archiveIdea: (id) => up((p) => ({ ...p, ideas: p.ideas.map((i) => (i.id === id ? { ...i, archived: true } : i)) })),
    updateProject: (id, patch) => up((p) => ({ ...p, projects: p.projects.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
    addTask: (projectId, title, due) => up((p) => ({ ...p, tasks: [...p.tasks, { id: uid(), projectId, title, due: due || undefined, done: false }] })),
    toggleTask: (id) => up((p) => ({ ...p, tasks: p.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)) })),
    deleteTask: (id) => up((p) => ({ ...p, tasks: p.tasks.filter((t) => t.id !== id) })),
    reset: () => setS(empty),
  };
  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}
