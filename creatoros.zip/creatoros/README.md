# CreatorOS

Idea → project → tasks → script, in a Next.js 14 (App Router) + TypeScript + Tailwind app.

## Run
    npm install
    npm run dev      # http://localhost:3000
    npm run build

## What works
- Landing page, Mission Control, Ideas, Projects, project detail (stage, publish date, tasks, script editor).
- Persistence is **demo mode**: everything is saved in this browser's localStorage only. Clearing site data erases it.
- Sample data loads only when you click the button, and is labelled "sample".

## Not built yet
- Supabase: `supabase/schema.sql` is provided (tables + row-level security) but the app does not use it yet. Auth and sync are the next step.
- AI script help, thumbnail planning, calendar, analytics, assets, search, integrations.
